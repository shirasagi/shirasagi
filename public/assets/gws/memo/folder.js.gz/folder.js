function Gws_Memo_Folder() {
}

Gws_Memo_Folder.render = function () {
  return $("#addon-gws-agents-addons-group_permission").hide();
};
