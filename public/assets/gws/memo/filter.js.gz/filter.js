function Gws_Memo_Filter() {
}

Gws_Memo_Filter.render = function () {
  return $("#addon-gws-agents-addons-group_permission").hide();
};
