// webpacker で生成するアセットを明示的に指定する。指定していないと Sprockets 4 からエラーになる。
//







// ビルドするアセット一覧（アルファベット順）
// 次のコマンドで、一覧を生成することができる
// find app/assets -name '*.js*' -o -name '*.css*' -o -name '*.scss*' | \
//   fgrep -v app/assets/builds/ | \
//   fgrep -v app/assets/config/ | \
//   fgrep -v "/lib/" | \
//   fgrep -v "/_" | \
//   sort | \
//   sed -e 's#app/assets/javascripts/##' | \
//   sed -e 's#app/assets/stylesheets/##' | \
//   sed -e 's#\.erb##' | \
//   sed -e 's#\.scss#.css#'

// javascript














































// css / scss


















// others like image

;
