# coding: utf-8
class SampleEgg::AnyController < ApplicationController
  # any codes
end
