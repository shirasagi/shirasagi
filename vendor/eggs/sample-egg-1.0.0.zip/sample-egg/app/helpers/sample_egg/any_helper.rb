# coding: utf-8
module SampleEgg::AnyHelper
  # any codes
end
